lt-comp lr apertium_hn_in_canonical_form.dix hi.morf.bin
lt-comp rl apertium_hn_in_canonical_form.dix hi.gen.bin
lt-expand  apertium_hn_in_canonical_form.dix hi_expanded
